<template>
  <div class="grid-cols-2 bg-gray-500 min-h-screen">
    
    <template v-if="!isLogin">
      <Menu/>
    </template>
    <router-link to="/"></router-link>
    <div :class="[isLogin ? 'md:ml-0' : 'md:ml-44']">
      <router-view/>
    </div>
  </div>
</template>

<script>
import Menu from './components/MenuAcesso.vue';
export default {
  name: 'App',
  components: {
    Menu
  },
  computed: {
    isLogin() {
      return this.$route.path === '/login';
    }
  }
}
</script>