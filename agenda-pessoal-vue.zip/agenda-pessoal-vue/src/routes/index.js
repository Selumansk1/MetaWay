import { createWebHistory, createRouter } from 'vue-router';

import Login from  '../components/Login.vue';
import Home from '../components/Home.vue';
import Usuarios from '../components/usuario/Usuarios.vue';
import Pessoas from '../components/pessoas/Pessoas.vue';
import FormPessoa from '../components/pessoas/FormPessoas.vue';
import Contatos from '../components/contato/Contatos.vue';
import FormContato from '../components/contato/FormContatos.vue';
import FormUsuario from '../components/usuario/FormUsuarios.vue';

const routes = [
  { path: '/', redirect: '/login'},
  { path: '/login', component: Login },
  { path: '/home', component: Home },
  { path: '/usuarios', component: Usuarios },
  { path: '/form-usuario/:id', name: 'form-usuario', component: FormUsuario},
  { path: '/form-usuario-novo', name: 'form-usuario-novo', component: FormUsuario},
  { path: '/pessoas', component: Pessoas },
  { path: '/form-pessoa/:id', name: 'form-pessoa', component: FormPessoa},
  { path: '/form-pessoa-nova/', name: 'form-pessoa-nova', component: FormPessoa},
  { path: '/contatos', component: Contatos },
  { path: '/form-contato/:id', name: 'form-contato', component: FormContato},
  { path: '/form-contato-novo/', name: 'form-contato-novo', component: FormContato},
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router;