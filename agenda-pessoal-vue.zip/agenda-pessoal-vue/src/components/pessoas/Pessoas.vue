<template>
    <div class="container mx-auto">
      <h1 class="text-2xl font-bold mb-4">Pessoas</h1>
      <div v-if="mensagem" class="text-green-600 mb-4">{{ mensagem }}</div>
    <div v-if="erro" class="text-red-600 mb-4">{{ erro }}</div>
      <div class="flex flex-col md:flex-row md:justify-between mb-4">
        <button @click="cadastrarPessoa" class="px-2 py-1 bg-blue-500 text-white rounded mb-2 md:mb-0 md:mr-2">Cadastrar Pessoa</button>
        <input v-model="filtros"
               type="text"
               placeholder="Pesquisar..."
               class="border p-2 mb-4 md:mb-0 md:w-1/2">
      </div>
      <ul>
        <li v-for="(pessoa, index) in pessoasFiltradas" :key="index" class="border-b py-2 flex justify-between items-center">
          <div>{{ pessoa.nome }}</div>
          <div>
            <button @click="editarPessoa(pessoa)" class="px-2 py-1 bg-blue-500 text-white rounded mr-2">Editar</button>
            <button @click="removerPessoa(pessoa.id)" class="px-2 py-1 bg-red-500 text-white rounded">Remover</button>
          </div>
        </li>
      </ul>     
    </div>
  </template>

<script>
import axios from 'axios';
export default {
    data() {
        return {
            pessoas: [],
            filtros: '',
            mensagem: '',
            erro: ''
        };
    },
    computed: {
        pessoasFiltradas() {
            if(!this.filtros) {
                return this.pessoas;
            }
            return this.pessoas.filter(pessoa => {
                return pessoa.nome.toLowerCase().includes(this.filtros.toLowerCase());
            });
        }
    },
    mounted() {
        this.carregarPessoas();
    },
    methods: {
        async carregarPessoas() {
            try {
                const token = localStorage.getItem('accessToken');
                if(!token) {
                console.error('Token não encontrado');
                return;
                }
                const response = await axios.post('https://demometaway.vps-kinghost.net:8485/api/pessoa/pesquisar', {nome: ''}, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                this.pessoas = response.data;
            } catch (error) {
                console.error('Erro ao carregar pessoas', error);
            }
        },
        editarPessoa(pessoa) {
            this.$router.push({ name: 'form-pessoa', params: { id: pessoa.id }});
        },
        cadastrarPessoa() {
            this.$router.push({ name: 'form-pessoa-nova'});
        },
        async removerPessoa(id) {
            debugger
            try {
                const token = localStorage.getItem('accessToken');
                if(!token) {
                console.error('Token não encontrado');
                return;
                }
                await axios.delete(`https://demometaway.vps-kinghost.net:8485/api/pessoa/remover/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                this.erro = '';
                this.mensagem = 'Pessoa removida com sucesso'
                this.pessoas = this.pessoas.filter(pessoa => pessoa.id !== id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } catch (error) {
                console.error('Erro ao remover pessoa:', error);
                this.erro = 'Erro ao removover pessoa!'
                this.mensagem = '';
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        },
    },
};
</script>