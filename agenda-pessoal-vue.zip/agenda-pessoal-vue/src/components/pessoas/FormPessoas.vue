  <template>
      <div class="max-w-md mx-auto">
        <h1 class="text-2xl font-bold mb-4">{{ getTitulo() }}</h1>
        <form 
          @submit.prevent="submitForm" 
          class="space-y-4">
          <div class="">
              <h1>Pessoa</h1>
              <div>
                <label for="nome" class="block text-sm font-medium text-gray-700">Nome:</label>
                <input placeholder="Informe seu nome" v-model="pessoa.nome" type="text" id="nome" name="nome" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="cpf" class="block text-sm font-medium text-gray-700">CPF:</label>
                <input v-mask="'###.###.###-##'" type="tel" placeholder="Informe o Nº do CPF" v-model="pessoa.cpfP" id="cpf" name="cpf" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
            </div>
          <div>
              <h1>Endereço</h1>
              <div>
                <label for="cep" class="block text-sm font-medium text-gray-700">CEP:</label>
                <input v-mask="'#####-###'" type="tel" placeholder="Informe o Nº do CEP" v-model="pessoa.cep" id="cep" name="cep" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="bairro" class="block text-sm font-medium text-gray-700">Bairro:</label>
                <input v-model="pessoa.bairro" type="text" id="bairro" name="bairro" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="logradouro" class="block text-sm font-medium text-gray-700">Logradouro:</label>
                <input v-model="pessoa.logradouro" type="text" id="logradouro" name="logradouro" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="numero" class="block text-sm font-medium text-gray-700">Numero:</label>
                <input v-model="pessoa.numero" type="text" id="numero" name="numero" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="cidade" class="block text-sm font-medium text-gray-700">Cidade:</label>
                <input v-model="pessoa.cidade" type="text" id="cidade" name="cidade" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="estado" class="block text-sm font-medium text-gray-700">Estado:</label>
                <input v-model="pessoa.estado" type="text" id="estado" name="estado" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
              <div>
                <label for="pais" class="block text-sm font-medium text-gray-700">Pais:</label>
                <input v-model="pessoa.pais" type="text" id="pais" name="pais" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
              </div>
            </div>
          <div class="flex justify-end">
            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-md">Salvar</button>
            <button @click="cancelEdit" type="button" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md ml-2">Cancelar</button>
          </div>
        </form>
      </div>
    </template>
  
  <script>
  import axios from 'axios';
  import {mask} from 'vue-the-mask';
export default {
  directives: {mask},
  data() {
    return {
      pessoa: {}
    };
  },
  methods: {
    async submitForm() {
    try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          console.error('Token não encontrado');
          return;
        }

        if(this.$route.params.id) {
          const id = this.$route.params.id;
          const responsePessoa = await axios.get(`https://demometaway.vps-kinghost.net:8485/api/pessoa/buscar/${id}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          if(responsePessoa.data != null){
              const pessoa = responsePessoa.data.object;
              //Pessoa
              pessoa.nome = this.pessoa.nome;
              pessoa.cpf = this.pessoa.cpfP;
              //Endereco
              pessoa.endereco.cep = this.pessoa.cep;
              pessoa.endereco.bairro = this.pessoa.bairro;
              pessoa.endereco.logradouro = this.pessoa.logradouro;
              pessoa.endereco.numero = this.pessoa.numero;
              pessoa.endereco.cidade = this.pessoa.cidade;
              pessoa.endereco.estado = this.pessoa.estado;
              pessoa.endereco.pais = this.pessoa.pais;
              const responsePessoaSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/pessoa/salvar', pessoa, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });
              console.log('Dados atualizados com sucesso:', responsePessoaSalvar.data);
              this.$router.push('/pessoas');
          }
  
  
        } else {
          const novaPessoa = {
    cpf: this.pessoa.cpfP,
    endereco: {
      bairro: this.pessoa.bairro,
      cep: this.pessoa.cep,
      cidade: this.pessoa.cidade,
      estado: this.pessoa.estado,
      id: 0,
      logradouro: this.pessoa.logradouro,
      numero: this.pessoa.numero,
      pais: this.pessoa.pais
    },
    id: 0,
    nome: this.pessoa.nome
      };
      const responseNovoPessoaSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/pessoa/salvar', novaPessoa, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
              console.log('Pessoa cadastrada com sucesso');
              this.$router.push('/pessoas');
        }
      } catch (error) {
        console.error('Erro ao atualizar pessoa:', error);
      }
  },
    cancelEdit() {
      console.log('Edição cancelada');
      this.$router.push('/pessoas');
    },
    async carregarPessoa(id) {
      try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          console.error('Token não encontrado');
          return;
        }
        const response = await axios.get(`https://demometaway.vps-kinghost.net:8485/api/pessoa/buscar/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if(response != null){
            const pessoa = response.data.object;
            //Pessoa
            this.pessoa.nome = pessoa.nome;
            this.pessoa.cpfP = pessoa.cpf;
            //Endereco
            this.pessoa.cep = pessoa.endereco.cep;
            this.pessoa.bairro = pessoa.endereco.bairro;
            this.pessoa.logradouro = pessoa.endereco.logradouro;
            this.pessoa.numero = pessoa.endereco.numero;
            this.pessoa.cidade = pessoa.endereco.cidade;
            this.pessoa.estado = pessoa.endereco.estado;
            this.pessoa.pais = pessoa.endereco.pais;
        }
        console.log(this.pessoa);
      } catch (error) {
        console.error('Erro ao carregar pessoa:', error);
      }
    },
    getTitulo() {
      if(this.$route.name == 'form-pessoa-nova') {
        return 'Cadastrar Pessoa';
      } else if(this.$route.params.id) {
        return 'Editar Pessoa';
      }
    }
  },
  mounted() {
    if(this.$route.params.id !== null) {
      const id = this.$route.params.id;
      this.carregarPessoa(id);
    }
  }
};
</script>

  