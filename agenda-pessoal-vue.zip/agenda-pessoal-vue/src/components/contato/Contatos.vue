<template>
    <div class="container mx-auto">
      <h1 class="text-2xl font-bold mb-4">Contatos</h1>
      <div class="flex flex-col md:flex-row md:justify-between mb-4">
        <button @click="cadastrarContato" class="px-2 py-1 bg-blue-500 text-white rounded mb-2 md:mb-0 md:mr-2">Cadastrar Contato</button>
        <input v-model="filtros"
               type="text"
               placeholder="Pesquisar..."
               class="border p-2 mb-4 md:mb-0 md:w-1/2">
      </div>
      <ul>
        <li v-for="(contato, index) in contatosFiltrados" :key="index" class="border-b py-2 flex justify-between items-center">
          <div>{{ contato.pessoa.nome }}</div>
          <div>
            <button @click="editarContato(contato)" class="px-2 py-1 bg-blue-500 text-white rounded mr-2">Editar</button>
            <button @click="removerContato(contato.id, contato.pessoa.id)" class="px-2 py-1 bg-red-500 text-white rounded">Remover</button>
          </div>
        </li>
      </ul>     
    </div>
  </template>
  

<script>
import axios from 'axios';
export default {
    data() {
        return {
            contatos: [],
            filtros: ''
        };
    },
    computed: {
        contatosFiltrados() {
            if(!this.filtros) {
                return this.contatos;
            }
            return this.contatos.filter(contato => {
                return contato.pessoa.nome.toLowerCase().includes(this.filtros.toLowerCase());
            });
        }
    },
    mounted() {
        this.carregarContatos();
    },
    methods: {
        async carregarContatos() {
            try {
                const token = localStorage.getItem('accessToken');
                if(!token) {
                console.error('Token não encontrado');
                return;
                }
                const response = await axios.post('https://demometaway.vps-kinghost.net:8485/api/contato/pesquisar', {termo: ''}, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                this.contatos = response.data;
            } catch (error) {
                console.error('Erro ao carregar contatos', error);
            }
        },
        editarContato(contato) {
            this.$router.push({ name: 'form-contato', params: { id: contato.pessoa.id }});
        },
        cadastrarContato() {
            this.$router.push({ name: 'form-contato-novo'});
        },
        async removerContato(id, idP) {
            try {
                const token = localStorage.getItem('accessToken');
                if(!token) {
                console.error('Token não encontrado');
                return;
                }
                await axios.delete(`https://demometaway.vps-kinghost.net:8485/api/pessoa/remover/${idP}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                await axios.delete(`https://demometaway.vps-kinghost.net:8485/api/contato/remover/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                this.contatos = this.contatos.filter(contato => contato.id !== id);
            } catch (error) {
                console.error('Erro ao remover contato:', error);
            }
        },
    },
};
</script>