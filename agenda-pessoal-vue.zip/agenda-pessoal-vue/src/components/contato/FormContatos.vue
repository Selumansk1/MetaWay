          <template>
              <div class="max-w-md mx-auto">
                <h1 class="text-2xl font-bold mb-4">{{ getTitulo() }}</h1>
                <form 
                  @submit.prevent="submitForm" 
                  class="space-y-4">
                  <div class="">
                      <h1>Pessoa</h1>
                      <div>
                        <label for="nome" class="block text-sm font-medium text-gray-700">Nome:</label>
                        <input placeholder="Informe seu nome" v-model="contato.nome" type="text" id="nome" name="nome" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="cpf" class="block text-sm font-medium text-gray-700">CPF:</label>
                        <input v-mask="'###.###.###-##'" type="tel" placeholder="Informe o Nº do CPF" v-model="contato.cpfP" id="cpf" name="cpf" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                    </div>
                  <div>
                      <h1>Endereço</h1>
                      <div>
                        <label for="cep" class="block text-sm font-medium text-gray-700">CEP:</label>
                        <input v-mask="'#####-###'" type="tel" placeholder="Informe o Nº do CEP" v-model="contato.cep" id="cep" name="cep" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="bairro" class="block text-sm font-medium text-gray-700">Bairro:</label>
                        <input v-model="contato.bairro" type="text" id="bairro" name="bairro" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="logradouro" class="block text-sm font-medium text-gray-700">Logradouro:</label>
                        <input v-model="contato.logradouro" type="text" id="logradouro" name="logradouro" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="numero" class="block text-sm font-medium text-gray-700">Numero:</label>
                        <input v-model="contato.numero" type="text" id="numero" name="numero" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="cidade" class="block text-sm font-medium text-gray-700">Cidade:</label>
                        <input v-model="contato.cidade" type="text" id="cidade" name="cidade" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="estado" class="block text-sm font-medium text-gray-700">Estado:</label>
                        <input v-model="contato.estado" type="text" id="estado" name="estado" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="pais" class="block text-sm font-medium text-gray-700">Pais:</label>
                        <input v-model="contato.pais" type="text" id="pais" name="pais" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                    </div>
                    <div>
                      <h1>Contato</h1>
                      <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">Tipo do contato:</label>
                        <input v-model="contato.tipoContato" type="text" id="email" name="email" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="telefone" class="block text-sm font-medium text-gray-700">Telefone:</label>
                        <input type="tel" 
                              v-mask="'(##) # ####-####'"
                              placeholder="Nº de Telefone" v-model="contato.telefone" id="telefone" name="telefone" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">E-mail:</label>
                        <input v-model="contato.email" type="email" id="email" name="email" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="tag" class="block text-sm font-medium text-gray-700">Tag:</label>
                        <input v-model="contato.tag" type="text" id="tag" name="tag" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="privado" class="block text-sm font-medium text-gray-700">Privado:</label>
                        <input v-model="contato.privado" id="privado" name="privado" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                  </div>
                  <!-- <div>
                      <h1>Usuário</h1>
                      <div>
                        <label for="nomeU" class="block text-sm font-medium text-gray-700">Nome:</label>
                        <input v-model="contato.nomeU" type="text" id="nomeU" name="nomeU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="dtNascimento" class="block text-sm font-medium text-gray-700">Data de Nascimento:</label>
                        <input type="tel" 
                              placeholder="Data de Nascimento"
                              v-mask="'##/##/####'" v-model="contato.dtNascimentoU" id="dtNascimento" name="dtNascimento" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="cpfU" class="block text-sm font-medium text-gray-700">CPF:</label>
                        <input v-mask="'###.###.###-##'" 
                              type="tel" 
                              placeholder="Informe o Nº do CPF" v-model="contato.cpfU" id="cpfU" name="cpfU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="telefoneU" class="block text-sm font-medium text-gray-700">Telefone:</label>
                        <input type="tel" 
                              v-mask="'(##) # ####-####'"
                              placeholder="Nº de Telefone" v-model="contato.telefoneU" id="telefoneU" name="telefoneU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="emailU" class="block text-sm font-medium text-gray-700">E-mail:</label>
                        <input v-model="contato.emailU" type="email" id="emailU" name="emailU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="usuario" class="block text-sm font-medium text-gray-700">Usuário:</label>
                        <input v-model="contato.usuario" type="text" id="usuario" name="usuario" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                  </div> -->
                  <div class="flex justify-end">
                    <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-md">Salvar</button>
                    <button @click="cancelEdit" type="button" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md ml-2">Cancelar</button>
                  </div>
                </form>
              </div>
            </template>
  
  <script>
  import axios from 'axios';
  import {mask} from 'vue-the-mask';
export default {
  directives: {mask},
  data() {
    return {
      contato: {}
    };
  },
  methods: {
    async submitForm() {
    try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          console.error('Token não encontrado');
          return;
        }

        if(this.$route.params.id) {
          const id = this.$route.params.id;
          const responseContato = await axios.get(`https://demometaway.vps-kinghost.net:8485/api/contato/listar/${id}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          if(responseContato.data.length > 0){
              const contato = responseContato.data[0];
              //Pessoa
              contato.pessoa.nome = this.contato.nome;
              contato.pessoa.cpf = this.contato.cpfP;
              //Endereco
              contato.pessoa.endereco.cep = this.contato.cep;
              contato.pessoa.endereco.bairro = this.contato.bairro;
              contato.pessoa.endereco.logradouro = this.contato.logradouro;
              contato.pessoa.endereco.numero = this.contato.numero;
              contato.pessoa.endereco.cidade = this.contato.cidade;
              contato.pessoa.endereco.estado = this.contato.estado;
              contato.pessoa.endereco.pais = this.contato.pais;
              //Contato
              contato.tipoContato = this.contato.tipoContato;
              contato.telefone = this.contato.telefone;
              contato.email = this.contato.email;
              contato.tag = this.contato.tag;
              contato.privado = this.contato.privado;
              //Usuario
              // contato.usuario.nome = this.contato.nomeU;
              // contato.usuario.dataNascimento = this.contato.dtNascimentoU;
              // contato.usuario.cpf = this.contato.cpfU;
              // contato.usuario.telefone = this.contato.telefoneU;
              // contato.usuario.email = this.contato.emailU;
              // contato.usuario.username = this.contato.usuario;
              // contato.usuario.password = this.contato.senha;
              debugger
              const responseContatoSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/contato/salvar', contato, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });
              const responsePessoaSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/pessoa/salvar', contato.pessoa, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });
              const responseUsuarioSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/usuario/salvar', contato.usuario, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });
              console.log('Dados atualizados com sucesso:', responseContatoSalvar.data, responsePessoaSalvar.data);
              this.$router.push('/contatos');
          }
  
  
        } else {
          debugger
          const novoContato = {
            email: this.contato.email,
  id: 0,
  pessoa: {
    cpf: this.contato.cpfP,
    endereco: {
      bairro: this.contato.bairro,
      cep: this.contato.cep,
      cidade: this.contato.cidade,
      estado: this.contato.estado,
      id: 0,
      logradouro: this.contato.logradouro,
      numero: this.contato.numero,
      pais: this.contato.pais
    },
    foto: {
      id: "",
      name: "",
      type: ""
    },
    id: 0,
    nome: this.contato.nome
  },
  privado: true,
  tag: this.contato.tag,
  telefone: this.contato.telefone,
  tipoContato: this.contato.tipoContato,
  usuario: {
    cpf: this.contato.cpfP,
    dataNascimento: "2024-05-11",
    email: this.contato.email,
    id: 0,
    nome: this.contato.nome,
    password: "123",
    telefone: this.contato.telefone,
    username: "will"
  }
      };
      debugger
      const responseNovoUsuarioSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/usuario/salvar', novoContato.usuario, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const responseNovoPessoaSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/pessoa/salvar', novoContato.pessoa, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      debugger
      novoContato.pessoa.id = responseNovoPessoaSalvar.data.id;
      novoContato.usuario.id = responseNovoUsuarioSalvar.data.id;
      const responseNovoContatoSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/contato/salvar', novoContato, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });
              console.log('Contato cadastrado com sucesso');
              this.$router.push('/contatos');
        }
      } catch (error) {
        console.error('Erro ao atualizar contato:', error);
      }
  },
    cancelEdit() {
      console.log('Edição cancelada');
      this.$router.push('/contatos');
    },
    async carregarContato(id) {
      try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          console.error('Token não encontrado');
          return;
        }
        const response = await axios.get(`https://demometaway.vps-kinghost.net:8485/api/contato/listar/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        debugger

        if(response.data.length > 0){
            const contato = response.data[0];
            //Pessoa
            this.contato.nome = contato.pessoa.nome;
            this.contato.cpfP = contato.pessoa.cpf;
            //Endereco
            this.contato.cep = contato.pessoa.endereco.cep;
            this.contato.bairro = contato.pessoa.endereco.bairro;
            this.contato.logradouro = contato.pessoa.endereco.logradouro;
            this.contato.numero = contato.pessoa.endereco.numero;
            this.contato.cidade = contato.pessoa.endereco.cidade;
            this.contato.estado = contato.pessoa.endereco.estado;
            this.contato.pais = contato.pessoa.endereco.pais;
            //Contato
            this.contato.tipoContato = contato.tipoContato;
            this.contato.telefone = contato.telefone;
            this.contato.email = contato.email;
            this.contato.tag = contato.tag;
            this.contato.privado = contato.privado;
            //Usuario
            // this.contato.nomeU = contato.usuario.nome;
            // this.contato.dtNascimentoU = contato.usuario.dataNascimento;
            // this.contato.cpfU = contato.usuario.cpf;
            // this.contato.telefoneU = contato.usuario.telefone;
            // this.contato.emailU = contato.usuario.email;
            // this.contato.usuario = contato.usuario.username;
            // this.contato.senha = contato.usuario.password;
        }
        console.log(this.contato);
      } catch (error) {
        console.error('Erro ao carregar contato:', error);
      }
    },
    getTitulo() {
      if(this.$route.name == 'form-contato-novo') {
        return 'Cadastrar Contato';
      } else if(this.$route.params.id) {
        return 'Editar Contato';
      }
    }
  },
  mounted() {
    if(this.$route.params.id !== null) {
      const id = this.$route.params.id;
      this.carregarContato(id);
    }
  }
};
</script>

  