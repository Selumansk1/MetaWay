<template>
    <div class="flex">
      <button @click="toggleMenu" class="md:hidden text-white text-2xl font-bold mb-4">Menu</button>
      <div :class="['menu', isOpen ? 'block' : 'hidden md:block', 'fixed inset-y-0 left-0 flex-col w-full md:w-40 bg-gray-700 z-40']">
        <div class="mt-2 flex flex-col justify-start items-start w-full md:w-48 text-center font-bold text-xl">
          <h1 class="text-white ml-2 mb-5">Menu</h1>
          <button class="text-white ml-2 mb-5" @click="home">Home</button>
          <button v-if="isAdmin" class="text-white ml-2 mb-5" @click="usuarios">Usuários</button>
          <button class="text-white ml-2 mb-5" @click="pessoas">Pessoas</button>
          <button class="text-white ml-2 mb-5" @click="contatos">Contatos</button>
          <button class="text-white ml-2 mb-5" @click="logout">Sair</button>
        </div>
      </div>
    </div>
  </template>

<script>
    export default {
        data() {
    return {
      isOpen: false,
      isAdmin: false,
    };
  },
        methods: {
            toggleMenu() {
      this.isOpen = !this.isOpen;
    },
            home() {
                this.isOpen = false;
                this.$router.push('/home');
            },
            usuarios() {
                this.isOpen = false;
                this.$router.push('/usuarios');
            },
            pessoas() {
                this.isOpen = false;
                this.$router.push('/pessoas');
            },
            contatos() {
                this.isOpen = false;
                this.$router.push('/contatos');
            },
            logout() {
                localStorage.removeItem('token');
                this.$router.push('/login');
            },
            checkAdminRole() {
      const user = localStorage.getItem('user');
      if (user && user.role === 'admin') {
        this.isAdmin = true;
      }
    },
        },
        
  created() {
    this.checkAdminRole();
  },
    }
</script>