<template>
    <div class="container mx-auto">
      <h1 class="text-2xl font-bold mb-4">Usuários</h1>
      <div v-if="mensagem" class="text-green-600 mb-4">{{ mensagem }}</div>
    <div v-if="erro" class="text-red-600 mb-4">{{ erro }}</div>
      <div class="flex flex-col md:flex-row md:justify-between mb-4">
        <button @click="cadastrarUsuario" class="px-2 py-1 bg-blue-500 text-white rounded mb-2 md:mb-0 md:mr-2">Cadastrar Usuário</button>
        <input v-model="filtros"
               type="text"
               placeholder="Pesquisar..."
               class="border p-2 mb-4 md:mb-0 md:w-1/2">
      </div>
      <ul>
        <li v-for="(usuario, index) in usuariosFiltrados" :key="index" class="border-b py-2 flex justify-between items-center">
          <div>{{ usuario.nome }}</div>
          <div>
            <button @click="editarUsuario(usuario)" class="px-2 py-1 bg-blue-500 text-white rounded mr-2">Editar</button>
          </div>
        </li>
      </ul>     
    </div>
  </template>

<script>
import axios from 'axios';
export default {
    data() {
        return {
            usuarios: [],
            filtros: '',
            mensagem: '',
            erro: ''
        };
    },
    computed: {
        usuariosFiltrados() {
            if(!this.filtros) {
                return this.usuarios;
            }
            return this.usuarios.filter(usuario => {
                return usuario.nome.toLowerCase().includes(this.filtros.toLowerCase());
            });
        }
    },
    mounted() {
        this.carregarUsuarios();
    },
    methods: {
        async carregarUsuarios() {
            try {
                const token = localStorage.getItem('accessToken');
                if(!token) {
                console.error('Token não encontrado');
                return;
                }
                const response = await axios.post('https://demometaway.vps-kinghost.net:8485/api/usuario/pesquisar', {termo: ''}, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                this.usuarios = response.data;
            } catch (error) {
                console.error('Erro ao carregar usuários', error);
            }
        },
        editarUsuario(usuario) {
            this.$router.push({ name: 'form-usuario', params: { id: usuario.id }});
        },
        cadastrarUsuario() {
            this.$router.push({ name: 'form-usuario-novo'});
        }
    },
};
</script>