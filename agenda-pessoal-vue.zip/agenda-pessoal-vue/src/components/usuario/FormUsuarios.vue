  <template>
      <div class="max-w-md mx-auto">
        <h1 class="text-2xl font-bold mb-4">{{ getTitulo() }}</h1>
        <form 
          @submit.prevent="submitForm" 
          class="space-y-4">
          
                  <div>
                      <h1>Usuário</h1>
                      <div>
                        <label for="nomeU" class="block text-sm font-medium text-gray-700">Nome:</label>
                        <input v-model="usuario.nome" type="text" id="nomeU" name="nomeU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="dtNascimento" class="block text-sm font-medium text-gray-700">Data de Nascimento:</label>
                        <input type="tel" 
                              placeholder="Data de Nascimento"
                              v-mask="'##/##/####'" v-model="usuario.dtNascimento" id="dtNascimento" name="dtNascimento" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="cpfU" class="block text-sm font-medium text-gray-700">CPF:</label>
                        <input v-mask="'###.###.###-##'" 
                              type="tel" 
                              placeholder="Informe o Nº do CPF" v-model="usuario.cpf" id="cpfU" name="cpfU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="telefoneU" class="block text-sm font-medium text-gray-700">Telefone:</label>
                        <input type="tel" 
                              v-mask="'(##) # ####-####'"
                              placeholder="Nº de Telefone" v-model="usuario.telefone" id="telefoneU" name="telefoneU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="emailU" class="block text-sm font-medium text-gray-700">E-mail:</label>
                        <input v-model="usuario.email" type="email" id="emailU" name="emailU" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                      <div>
                        <label for="usuario" class="block text-sm font-medium text-gray-700">Usuário:</label>
                        <input v-model="usuario.usuario" type="text" id="usuario" name="usuario" class="mt-1 p-2 block w-full border border-gray-300 rounded-md">
                      </div>
                  </div>
          <div class="flex justify-end">
            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-md">Salvar</button>
            <button @click="cancelEdit" type="button" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md ml-2">Cancelar</button>
          </div>
        </form>
      </div>
    </template>
  
  <script>
  import axios from 'axios';
  import {mask} from 'vue-the-mask';
export default {
  directives: {mask},
  data() {
    return {
      usuario: {}
    };
  },
  methods: {
    async submitForm() {
    try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          console.error('Token não encontrado');
          return;
        }

        if(this.$route.params.id) {
          const id = this.$route.params.id;
          const responseUsuario = await axios.get(`https://demometaway.vps-kinghost.net:8485/api/usuario/buscar/${id}`, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          if(responseUsuario.data != null){
              const usuario = responseUsuario.data.object.usuario;
              usuario.nome = this.usuario.nome;
              usuario.dataNascimento = this.usuario.dtNascimento;
              usuario.cpf = this.usuario.cpf;
              usuario.telefone = this.usuario.telefone;
              usuario.email = this.usuario.email;
              usuario.username = this.usuario.usuario;
              usuario.password = this.usuario.senha;
              const responsePessoaSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/usuario/salvar', usuario, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });
              console.log('Dados atualizados com sucesso:', responsePessoaSalvar.data);
              this.$router.push('/usuarios');
          }
  
  
        } else {
          const novoUsuario = {
            cpf: this.usuario.cpf,
    dataNascimento: "2024-05-11",
    email: this.usuario.email,
    id: 0,
    nome: this.usuario.nome,
    password: "123",
    telefone: this.usuario.telefone,
    username: "will"
      };
      const responseNovoPessoaSalvar = await axios.post('https://demometaway.vps-kinghost.net:8485/api/usuario/salvar', novoUsuario, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
              console.log('Usuario cadastrado com sucesso');
              this.$router.push('/usuarios');
        }
      } catch (error) {
        console.error('Erro ao atualizar usuario:', error);
      }
  },
    cancelEdit() {
      console.log('Edição cancelada');
      this.$router.push('/usuarios');
    },
    async carregarUsuario(id) {
      debugger
      try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          console.error('Token não encontrado');
          return;
        }
        const response = await axios.get(`https://demometaway.vps-kinghost.net:8485/api/usuario/buscar/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        if(response != null){
            const usuario = response.data.object.usuario;
            //Pessoa
            this.usuario.nome = usuario.nome;
            this.usuario.cpf = usuario.cpf;
            //Endereco
            this.usuario.dataNascimento = usuario.dataNascimento;
            this.usuario.telefone = usuario.telefone;
            this.usuario.email = usuario.email;
            this.usuario.username = usuario.username;
            this.usuario.password = usuario.password;
        }
        console.log(this.usuario);
      } catch (error) {
        console.error('Erro ao carregar Usuário:', error);
      }
    },
    getTitulo() {
      if(this.$route.name == 'form-usuario-novo') {
        return 'Cadastrar Usuário';
      } else if(this.$route.params.id) {
        return 'Editar Usuário';
      }
    }
  },
  mounted() {
    if(this.$route.params.id !== null) {
      const id = this.$route.params.id;
      this.carregarUsuario(id);
    }
  }
};
</script>

  