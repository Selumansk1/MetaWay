<template>
    <div class="h-screen font-sans login bg-cover">
        <div class="container mx-auto h-full flex flex-1 justify-center items-center">
            <div class="w-full max-w-lg">
                <div class="leading-loose">
                    <form class="max-w-sm m-4 p-10 bg-white bg-opacity-25 rounded shadow-xl" @submit.prevent="login">
                        <p class="text-white text-center text-lg font-bold">LOGIN</p>
                        <div class="mb-4">
                            <label 
                                for="usuario" 
                                class="block text-gray-700 text-sm font-bold mb-2">
                                Usuário
                            </label>
                            <input 
                                v-model="usuario" 
                                type="text" 
                                id="usuario" 
                                name="usuario" 
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                placeholder="Usuário">
                        </div>
                        <div class="mb-6">
                            <label 
                                for="senha" 
                                class="block text-gray-700 text-sm font-bold mb-2">
                                Senha
                            </label>
                            <input 
                                v-model="senha" 
                                type="password" 
                                id="senha" 
                                name="senha" 
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                placeholder="Senha">
                        </div>
                        <div class="mb-6 flex items-center justify-between">
                            <label 
                                for="lembrar" 
                                class="flex items-center">
                                <input 
                                    v-model="lembrar"
                                    type="checkbox"
                                    id="lembrar"
                                    name="lembrar"
                                    class="form-checkbox h-5 w-5 text-gray-600">
                                <span class="ml-2 text-sm text-gray-700">Lembrar se</span>
                            </label>
                        </div>
                        <div>
                            <button 
                                @click="login"
                                type="button" 
                                class="w-full bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                                Entrar
                        </button>
                        </div>
                        <div v-if="erro" class="text-red-500 text-sm mt-2">
                            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" 
                                role="alert">
                                <strong class="font-bold">{{ erro }}</strong>
                                <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
                                    <svg 
                                        @click="limparErro"
                                        class="fill-current h-6 w-6 text-red-500" 
                                        role="button" 
                                        xmlns="http://www.w3.org/2000/svg" 
                                        viewBox="0 0 20 20">
                                            <title>
                                                Close
                                            </title>
                                            <path 
                                            d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/>
                                    </svg>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from 'axios'; 
    export default {
        data() {
            return {
                usuario: '',
                senha: '',
                lembrar: false,
                erro: '',
            };
        },
        methods: {
            async login() {
                try {
                    const response = await axios.post('https://demometaway.vps-kinghost.net:8485/api/auth/login', {
                       password: this.senha,
                       username: this.usuario 
                    });
                    if (response.status === 200) {
            const token = response.data.accessToken;
            localStorage.setItem('accessToken', token);
            this.$router.push('/home');
        } else {
            console.error('Erro ao fazer login:', response.data); // ou qualquer mensagem de erro adequada
            this.erro = 'Erro ao fazer login. Por favor, tente novamente.';
        }
                } catch (error) {
                    console.error('Erro de login', error);
                    this.erro = 'Usuário não encontrado !'
                }
            },
            limparErro() {
                this.erro = '';
            }
        }
    }
</script>