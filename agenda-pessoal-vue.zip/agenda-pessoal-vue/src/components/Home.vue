<template>
    <div class="container mx-auto">
      <ListaContato />
  </div>
</template>

<script>
import ListaContato from './contato/Contatos.vue';
export default {
  components: {
    ListaContato
  }
}
</script>